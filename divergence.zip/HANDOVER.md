# HANDOVER — PASTE THIS FIRST IN THE NEW CHAT
### DIVERGENCE · Reverie Hacks 2026 · ML Prompt Engineering
**Written 7 August 2026 · Submission 17 August**

---

# HOW TO START THE NEW CHAT

**Step 1 — Add these to Project Knowledge** (not just the chat — Project Knowledge is searchable from every chat in the project):
- `STEP-LOG.md` ← **the single most important file. Everything is in it.**
- This handover
- `divergence.zip` (or at least `corpus/`, `citation_matcher.py`, `schema.json`)
- `problem-statement.md`, `users.md`, `scope.md`, `baseline-prompt.md`

**Step 2 — First message in the new chat:**

> I'm continuing the DIVERGENCE project (Reverie Hacks, ML Prompt Engineering track). Read HANDOVER.md and STEP-LOG.md in the project files. We're on Step 18 of 40. Continue from there.

That's it. A fresh instance can pick up from the log.

---

# WHAT THE PROJECT IS — IN FIVE LINES

An Indian freelancer is paid $5,000 in USDC. To file, she needs one number: what it was worth in rupees. **No method is prescribed for that number.** Two defensible methods differ by **₹43,633 (9.27%)** on one invoice.

We built a workflow that reports the gap instead of hiding it.

**One-liner:** *An AI can say "I don't know." It cannot say "nobody knows." We built the workflow that can.*

**Descriptor:** *DIVERGENCE — a record of what the law didn't decide.*

---

# THE FACTS THAT MUST NOT DRIFT

Any new chat must use these exact figures. They were retrieved, computed and verified — not estimated.

| Fact | Value |
|---|---|
| Headline gap | **₹43,633 · 9.27%** on one $5,000 invoice |
| Method A — Indian market | CoinDCX `I-USDT_INR`, 28 Jun 2026 close **102.83** → ₹5,14,150 |
| Method B — SBI TT buying rate | 25 Jun 2026 **94.00** × peg 1.0011 → ₹4,70,517 |
| Settlement | **03:14 IST, Sunday 28 June 2026** (= 21:44 UTC Saturday 27 June) |
| SBI publication gap | Published 25 Jun, **skipped 26 Jun**, next 29 Jun — **four-day hole** |
| 29 June intraday range | **10.52%** — low **93.50**, essentially the official rate |
| GST exposure if zero-rating fails | ₹1,19,205 non-fraud · ₹2,01,752 fraud |
| Enforcement | CBDT issued **44,057** communications for VDA under-reporting |

**Six undetermined choices, all priced:** which method (₹43,633) · which SBI date (₹250) · which intraday price (₹5,500) · IST or UTC date · the RBI-delta workaround · **and the random 15-minute window inside FBIL's own rate.**

---

# THE FIVE FINDINGS THAT CARRY THE PROJECT

**1. The gap is a closed chain, provable in five steps, all primary text in our corpus.**
s.2(47A) defines a VDA → s.56(2)(x) Explanation (b) says property *"shall include virtual digital asset"* → Explanation to (vii)(b) says fair market value **MEANS** *"the value determined in accordance with the method as may be prescribed"* → Rule 11UA/57 is the prescribing rule → **it contains zero VDA references (machine-checked).**

> **In the same Explanation, Parliament extended "property" to cover VDAs and left "fair market value" pointing at a rule that doesn't reach them.**

**2. ⭐ India HAS prescribed a crypto valuation method — for exchanges, not taxpayers.**
The Income-tax Rules 2026 give reporting crypto-asset service providers a four-step waterfall ending: ***"a reasonable estimate may be applied as a measure of last resort."*** And sub-clause (iv): ***"the method shall be indicated in Form No. 167."***
**Method disclosure is already Indian law. It applies to the exchange, not to the person whose income it is. Our product is that rule reaching one person further.**

**3. FEMA s.3(c) is an express prohibition, not an inference.** *"No person shall receive otherwise than through an authorised person, any payment … on behalf of any person resident outside India in any manner."* Note it says **"any payment"**, not "foreign exchange" — s.3(a) and s.8 use the narrow term. The only question left: is a stablecoin transfer a "payment"?

**4. Reasoning models are 24% WORSE at abstention** (AbstentionBench, NeurIPS 2025), and give definitive answers *"even when their reasoning chains express uncertainty."*
> **We don't make the model more uncertain. We stop its uncertainty being thrown away.**

**5. s.439(8)(a)** (formerly 270A(6)) — bona fide explanation with disclosed facts = **no penalty**. ITAT: penalty *"cannot be levied where the addition is based on a difference in legal view or **computational methodology**."* **CGST s.74A Explanation 2 does the same job independently.** Disclosure is the hinge in both regimes.

---

# ARCHITECTURE — LOCKED

**"Five model calls and two deterministic checks."** Never "seven nodes."

1. Intake + extraction 🤖
2. Gap detector 🤖 — **runs before any reasoning**
3. Dual valuation + uncertainty budget 🤖
4. Regime resolver ×3, scoped corpus per pass 🤖
5. Adversarial checker 🤖 — **publishes the attack, doesn't silently revise**
✓ **Citation matcher** ⚙️ deterministic — built, 15/15
✓ **Gap constraint enforcer** ⚙️ deterministic — not built

**Pitch structure: open specific → widen once → land specific.** Never open with the word "crypto."

---

# LANGUAGE RULES — NEVER DRIFT FROM THESE

| ❌ Never say | ✅ Say |
|---|---|
| "Makes your payments compliant" | "An evidence and disclosure layer. It does not make any flow compliant." |
| "Every tool picks one silently" | "They disclose the input. They do not disclose the decision." |
| "The law prescribes no method" | "Within the provisions in our manifest, no method is prescribed." |
| "Receiving crypto is illegal under FEMA" | "s.3(c) prohibits receiving any payment from abroad otherwise than through an authorised person. The only question is whether a stablecoin transfer is a 'payment'." |
| "Rule 115 mandates the SBI rate" | "Rule 115 converts *foreign currency*. A VDA is defined as not being foreign currency, so it doesn't apply." |
| "We discovered a third uncertainty category" | "We think this is a case the standard split doesn't cover." |
| Any citation without a tax year | **Both numbering systems are live. Always attach the year.** |

---

# STATE OF PLAY

## ✅ Done — steps 1, 4, 5, 7, 8, 9, 11, 12, 13, 15, 16, 17
Rubric mapped · root cause · users · research audit · novelty · **corpus complete (16 files, verbatim, hashed)** · 34-idea brainstorm · inversion + pre-mortems · selection + 4 decisions locked · **kill gate PASSED and reproduced on two machines** · **baseline frozen** · **citation matcher built, 15/15**

## 🟡 Partly done
- **Step 3** — statement done, **30-second test not recorded**
- **Step 10** — protocol + catalogue ready, **no runs**
- **Step 14** — scope contract written, **unsigned**

## 🔴 Open and overdue — none needs research
1. **Send the three messages** to family CAs. *"Is there a method everyone uses, or does each person decide?"* **This is the only clock you don't control, and it gates Bounty 2.**
2. **Sign the scope contract** — 10 min, passes Gate C
3. **Record the 30-second test** — 45 min, all three

## ⏰ Deadlines
- **Bounty 1** — closes 9 Aug 23:59 UTC−5 = **10 Aug 10:29 IST**. Draft ready, form open
- **Bounty 2** — opens 9 Aug, closes 15 Aug. **Needs 3 reviewers = the interview people**
- **Submission** — 17 Aug 10:30 IST. **Submit by 08:00**

## Next step
**Step 18 — cost and latency model.** ~1 hour. Answers Sustainability's *"what does it cost to run?"* with a number.

Then 19–24 (design), 25 (**30 test documents — 8 h, biggest task, not started**), 26–31 (build + measure), 32–40 (bounties, presentation, submit).

---

# THE HABITS THAT PRODUCED EVERYTHING GOOD

Carry these into the new chat. They are the method, not decoration.

1. **Attack your own idea on purpose.** Every one of the five findings came from trying to disprove ourselves.
2. **Five times a citation we relied on was stale. We caught all five ourselves.** Rule 11UA→57 · 270A(6)→439(8) · interbank→SBI→Rule 115 doesn't apply · CGST 73/74→74A · s.56 pre-2022 text.
3. **A rule you can't enforce isn't a rule.** Prompt instructions don't guarantee; code does.
4. **Ship the data with the code.** Two failures in two days from the logic being fine and the data absent.
5. **A green test doesn't mean a readable output.** The v4 bug passed every assertion and would have confused a judge live.
6. **Report where you lose.** Publish the baseline, show the cases it wins.
7. **Every claim has a professional ancestor** — IFRS 13, metrology, auditing, legal opinions, FIN 48. That's evidence the problem is real, not that the idea is unoriginal.

---

# FILES

| File | What |
|---|---|
| **`STEP-LOG.md`** | **Everything. Start here.** ~170 numbered "remember" items |
| `divergence.zip` | corpus (16 files) + all scripts, ready to run |
| `citation_matcher.py` | 15/15, deterministic, tax-year aware |
| `killgate.py` | Rate data — already GO |
| `schema.json` | Output contract; `minItems:2` on valuation methods |
| `output-interface.html` | Built, accessible, ledger-styled |
| `baseline-prompt.md` | **Frozen. Do not edit.** |
| `problem-statement.md` | 3 lengths + defences + Q&A reserve |
| `scope.md` | In / deferred / never / never-say |
| `BOUNTY-1-five-year-vision.md` | Ready to submit |
| `iteration-log.md` | v1–v4 of the matcher, real not reconstructed |
| `COMPLETE-ROADMAP.md` | All 40 steps |

---

# ONE LINE FOR THE NEW CHAT

> **The thinking is done to an unusual depth. The building has barely started. Everything that scores is still ahead — and the three overdue items need messages and signatures, not more research.**
