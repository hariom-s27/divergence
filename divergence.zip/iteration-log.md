# ITERATION LOG
### Every change to a prompt, a node, or the corpus — with the reason and the result
**Started 6 August 2026 · Owner: P2, but everyone writes their own entries**

---

## WHY THIS FILE EXISTS

The ML track's Technical Execution criterion — 100 points across four judges — says, word for word:

> *"Quality and structure of the prompt/workflow design; measurable improvement over a naive baseline; **documented iteration and testing across inputs and edge cases**."*

**Most teams score zero on the third clause.** Not because the work is hard, but because nobody writes it down while it happens and it cannot be reconstructed afterwards.

**Write the entry at the moment of the change.** Retrospective reconstruction is both harder and less believable.

---

## HOW TO WRITE AN ENTRY

Copy this block. Fill it. Never delete an old one.

```
### [DATE] · [WHAT] · v[N]
Changed:
Why:
Result before → after:
Kept? yes / no / partly
```

**Two rules:**
- **Log the failures too.** An entry saying *"tried X, made it worse, reverted"* is worth more than one saying it worked — it shows you were testing rather than decorating.
- **Numbers where you have them.** *"Extraction accuracy on blurry inputs 4/10 → 7/10"* beats *"seemed better."*

---

# ENTRIES

### 2026-08-04 · Baseline prompt · v1
**Changed:** Wrote the single-prompt baseline.
**Why:** It has to exist before the pipeline, or we will unconsciously weaken it later. A baseline written after the fact is a target you moved.
**Result:** Frozen. Published in full in `baseline-prompt.md`.
**Kept?** Yes — and it must never be edited.

---

### 2026-08-06 · Schema · v1
**Changed:** Locked `schema.json`. `valuation.methods` set to `minItems: 2`. `limits[]` set to `minItems: 1`. `tax_year` made required on every citation.
**Why:** Encode the thesis as a constraint rather than an intention. A single valuation figure should be a schema violation, not a judgement call at 2 a.m. on the 15th.
**Result:** Validates as JSON. 12 top-level properties, 4 definitions.
**Kept?** Yes.

---

### 2026-08-06 · Interface · v2
**Changed:** Removed the pre-selected default from the election control.
**Why:** Writing the scope contract exposed a contradiction — rule 1 says we never advise, but a pre-selected default *is* a recommendation. Defaults dominate choice.
**Result:** Election is now optional; the record is valid without it, because the material fact is that both figures were shown.
**Kept?** Yes. Removed the friction *and* the advice in one move.

---

### 2026-08-06 · Headline figure · v2
**Changed:** ₹41,150 → **₹43,633**. Rate source changed from interbank (₹94.65) to SBI TT buying rate (₹94.00).
**Why:** Interbank has no standing in Indian tax law. Rule 115 mandates the SBI TTBR.
**Result:** Gap widened from 8.7% to **9.27%**. Verified against archived SBI PDFs.
**Kept?** Yes. **The legally correct rate made the claim both bigger and safer.**

---

### 2026-08-06 · Citation matcher · v1
**Changed:** Built the deterministic citation matcher. Whole-string substring matching after normalisation.
**Why:** Prompt instructions don't enforce anything. A citation check has to be code.
**Result:** **12/15 on the self-test.** Three false negatives on *real* citations: `Section 439(8)(a)` (sub-clause depth), `Section 2(6) IGST Act` (act-name variant), `FEMA section 3` (multi-provision file).
**Kept?** No — rewritten.

---

### 2026-08-06 · Citation matcher · v2
**Changed:** Replaced substring matching with structured parsing — every citation resolves to `(instrument, base number, bracket chain)`. Bracket chains match on prefix, so `439(8)(a)` matches stored `439(8)`.
**Why:** All three v1 failures were the same underlying error — comparing strings instead of references.
**Result:** **14/15.** One left: `Section 74A CGST` for FY 2022-23 returned VERIFIED instead of STALE.
**Kept?** Partly.

---

### 2026-08-06 · Citation matcher · v3
**Changed:** Two fixes. (1) Strip explanatory prose from citation fields before parsing. (2) Move the s.74A currency check above the generic year check.
**Why:** The bug was not in the matcher. The corpus header read `"Section 50, CGST Act 2017 — with a note on ss.73, 74 and 74A"`, so parsing that field pulled out **four** references and the wrong file matched first.
**Result:** **15/15.** Corpus header also cleaned.
**Kept?** Yes.

**Rule adopted:** *a citation field contains a citation, not a note about one.* Notes go in a separate `note:` key. **The data was wrong, not the code — and the test found it.**

---

### 2026-08-07 · First run on the team machine · P3
**Changed:** Ran `run_all.py` and `citation_matcher.py` on Windows for the first time.
**Why:** Verify the scripts work outside the environment they were written in.
**Result:** Kill gate **PASSED**, reproducing the same figures independently — 28 June close **102.83**, 29 June low **93.50**, history back to March 2025. Citation matcher scored **4/15** — the `corpus/` folder was not on the machine. **Not a code fault.** After extracting the bundle: **15/15**.
**Kept?** Yes.

**Lesson: ship the data with the code, not separately.** Same class of error as matcher v3 — the logic was fine and the data wasn't there. **Twice in two days.** Worth treating as a pattern rather than two accidents.

---

### 2026-08-07 · Citation matcher · v4
**Changed:** On a `VERIFIED` result, `should_cite` now echoes the citation correct **for that tax year**, not always the current one.
**Why:** Found by reading the team's own demo output. `Rule 11UA / FY 2025-26` returned **VERIFIED** and then said *"Rule 57, Income-tax Rules, 2026"* — which reads as a contradiction. A judge would ask *"so is it right or isn't it?"* For FY 2025-26 the correct citation **is** Rule 11UA.
**Result:** Still 15/15. Verified rows now print `✓ correct for FY 2025-26: Rule 11UA, Income-tax Rules, 1962`.
**Kept?** Yes.

**Found by running the demo, not by testing.** The test asserted on `status` only, so it passed while the human-facing output was misleading. **A green test does not mean the output makes sense to a reader.**

---

## ⬇ ADD YOUR ENTRIES BELOW THIS LINE
